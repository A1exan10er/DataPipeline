.bail on
BEGIN IMMEDIATE;
DELETE FROM access_token
WHERE uid = 1
  AND name = 'datapipeline-codex-merge-20260831';
SELECT changes();
COMMIT;
