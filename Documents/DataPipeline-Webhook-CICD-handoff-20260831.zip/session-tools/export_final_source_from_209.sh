#!/usr/bin/env bash
set -euo pipefail

readonly SHA="3fcc259694712ecc94dab6fc8bb4ea34026e37be"
readonly ARCHIVE="datapipeline-cicd-final-source-$SHA.tar.gz"
readonly BARE_REPOSITORY="/data/git/repositories/yangtianyu/datapipeline.git"

test ! -e "/tmp/$ARCHIVE"
docker exec --user git gitea test ! -e "/tmp/$ARCHIVE"
docker exec --user git gitea git \
  --git-dir="$BARE_REPOSITORY" \
  archive \
  --format=tar.gz \
  --output="/tmp/$ARCHIVE" \
  "$SHA" \
  deploy \
  Werkzeuge/check_task_device_reference.py
docker cp "gitea:/tmp/$ARCHIVE" "/tmp/$ARCHIVE"
sha256sum "/tmp/$ARCHIVE"
