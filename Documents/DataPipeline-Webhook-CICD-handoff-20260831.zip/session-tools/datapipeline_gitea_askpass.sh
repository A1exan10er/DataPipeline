#!/usr/bin/env bash
set -euo pipefail

case "${1:-}" in
  *Username*)
    printf '%s\n' 'qualitycheck-status-bot'
    ;;
  *)
    exec sed -n '1p' /home/xinzhi/.config/datapipeline/gitea-status-token
    ;;
esac
