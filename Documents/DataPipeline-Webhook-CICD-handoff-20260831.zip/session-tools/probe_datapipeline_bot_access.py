import json
import urllib.request


with open(
    "/home/xinzhi/.config/datapipeline/gitea-status-token",
    encoding="utf-8",
) as token_file:
    token = token_file.read().strip()

request = urllib.request.Request(
    "http://127.0.0.1:3000/api/v1/repos/yangtianyu/DataPipeline",
    headers={"Authorization": f"token {token}"},
)
with urllib.request.urlopen(request, timeout=10) as response:
    data = json.load(response)

print("BOT_REPO_ACCESS_OK", data["full_name"], data["private"])
