import json
import urllib.error
import urllib.parse
import urllib.request


BASE_URL = "http://127.0.0.1:3000/api/v1"
ADMIN_TOKEN_PATH = "/tmp/datapipeline-codex-admin-token"
STATUS_TOKEN_PATH = "/home/xinzhi/.config/datapipeline/gitea-status-token"
TEMP_TOKEN_NAME = "datapipeline-codex-bootstrap-20260831"


def call(method: str, path: str, token: str, body: dict | None = None) -> int:
    data = None if body is None else json.dumps(body).encode("utf-8")
    request = urllib.request.Request(
        BASE_URL + path,
        data=data,
        method=method,
        headers={
            "Authorization": f"token {token}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return response.status
    except urllib.error.HTTPError as error:
        return error.code


with open(ADMIN_TOKEN_PATH, encoding="utf-8") as token_file:
    admin_token = token_file.read().strip()

collaborator_path = (
    "/repos/yangtianyu/DataPipeline/collaborators/qualitycheck-status-bot"
)
grant_status = call("PUT", collaborator_path, admin_token, {"permission": "write"})
if grant_status != 204:
    raise SystemExit(f"failed to grant status-bot repository access: HTTP {grant_status}")

delete_path = "/users/admin/tokens/" + urllib.parse.quote(TEMP_TOKEN_NAME, safe="")
delete_status = call("DELETE", delete_path, admin_token)
if delete_status != 204:
    raise SystemExit(f"failed to revoke temporary admin token: HTTP {delete_status}")

with open(STATUS_TOKEN_PATH, encoding="utf-8") as token_file:
    status_token = token_file.read().strip()

access_status = call("GET", "/repos/yangtianyu/DataPipeline", status_token)
if access_status != 200:
    raise SystemExit(f"status bot cannot access DataPipeline: HTTP {access_status}")

print("STATUS_BOT_WRITE_ACCESS_OK_AND_TEMP_ADMIN_TOKEN_REVOKED")
