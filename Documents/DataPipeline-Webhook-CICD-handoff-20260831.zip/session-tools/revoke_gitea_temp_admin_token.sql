.bail on
BEGIN IMMEDIATE;
DELETE FROM access_token
WHERE id = 40
  AND uid = 1
  AND name = 'datapipeline-codex-bootstrap-20260831';
SELECT changes();
COMMIT;
