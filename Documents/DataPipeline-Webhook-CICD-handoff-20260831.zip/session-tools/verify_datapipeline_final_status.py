import json
import urllib.request


sha = "3fcc259694712ecc94dab6fc8bb4ea34026e37be"
with open(
    "/home/xinzhi/.config/datapipeline/gitea-status-token",
    encoding="utf-8",
) as handle:
    token = handle.read().strip()
request = urllib.request.Request(
    f"http://127.0.0.1:3000/api/v1/repos/yangtianyu/DataPipeline/commits/{sha}/status",
    headers={"Authorization": f"token {token}"},
)
with urllib.request.urlopen(request, timeout=10) as response:
    status = json.load(response)
if status["state"] != "success":
    raise SystemExit(f"unexpected combined commit status: {status['state']}")
matching = [
    item
    for item in status.get("statuses", [])
    if item.get("context") == "DataPipeline Webhook CI/CD"
]
if not matching or matching[0]["status"] != "success":
    raise SystemExit("fixed Webhook CI/CD success status is missing")
print("GITEA_COMMIT_STATUS_OK", status["state"], matching[0]["context"])
