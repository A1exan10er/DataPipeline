import json
import urllib.request


with open("/tmp/datapipeline-codex-webhook-admin-token", encoding="utf-8") as handle:
    token = handle.read().strip()

request = urllib.request.Request(
    "http://127.0.0.1:3000/api/v1/repos/yangtianyu/DataPipeline/hooks?limit=50",
    headers={"Authorization": f"token {token}"},
)
with urllib.request.urlopen(request, timeout=10) as response:
    hooks = json.load(response)

for hook in hooks:
    print(
        json.dumps(
            {
                "id": hook["id"],
                "name": hook.get("name"),
                "type": hook.get("type"),
                "active": hook.get("active"),
                "branch_filter": hook.get("branch_filter"),
                "events": hook.get("events"),
                "url": hook.get("config", {}).get("url"),
                "content_type": hook.get("config", {}).get("content_type"),
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
