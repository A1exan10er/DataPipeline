import hashlib
import hmac
import json
import urllib.request


commit_sha = "ac378f948b22e0b18e1e30a69fa93d99da0c47b1"
payload = json.dumps(
    {
        "ref": "refs/heads/master",
        "after": commit_sha,
        "repository": {"full_name": "yangtianyu/DataPipeline"},
    },
    separators=(",", ":"),
).encode("utf-8")
with open(
    "/home/xinzhi/DataPipeline-deploy/webhook/secret",
    "rb",
) as secret_file:
    secret = secret_file.read().strip()
signature = hmac.new(secret, payload, hashlib.sha256).hexdigest()
request = urllib.request.Request(
    "http://172.20.0.1:4014/gitea/datapipeline",
    data=payload,
    method="POST",
    headers={
        "Content-Type": "application/json",
        "X-Gitea-Event": "push",
        "X-Gitea-Signature": signature,
        "X-Gitea-Delivery": "codex-end-to-end-20260831",
    },
)
with urllib.request.urlopen(request, timeout=10) as response:
    body = json.load(response)
if response.status != 202 or body.get("status") != "accepted":
    raise SystemExit(f"unexpected webhook response: HTTP {response.status} {body}")
print("DATAPIPELINE_CICD_ACCEPTED", body["after"])
