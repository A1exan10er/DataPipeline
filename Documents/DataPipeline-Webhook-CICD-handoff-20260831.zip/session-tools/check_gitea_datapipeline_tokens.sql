.headers on
.mode list
PRAGMA table_info(access_token);
SELECT id, uid, name, scope
FROM access_token
WHERE name IN (
  'datapipeline-codex-bootstrap-20260831',
  'datapipeline-webhook-status-20260831'
);
