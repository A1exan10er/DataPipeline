#!/usr/bin/env bash
set -euo pipefail

sha="$(docker exec --user git gitea git \
  --git-dir=/data/git/repositories/yangtianyu/datapipeline.git \
  rev-parse refs/heads/master)"

printf 'MASTER=%s\n' "$sha"
systemctl --user is-active \
  datapipeline-webhook.service \
  datapipeline-deploy-status.service \
  datapipeline-dashboard.service \
  datapipeline-event-listener.service
systemctl --user show datapipeline-webhook.service \
  -p ExecStart -p ActiveState -p SubState --no-pager
curl -fsS http://172.20.0.1:4014/healthz
printf '\n'
grep -E '^EXPECTED_REPOSITORY|^EXPECTED_REF|^JOB_PATH' \
  /usr/local/libexec/datapipeline-webhook-server
docker exec gitea sqlite3 -json /data/gitea/gitea.db \
  "SELECT id, repo_id, is_active, events, url, name, meta FROM webhook WHERE id = 5;"
printf '\n'
status_file="/home/xinzhi/DataPipeline-deploy/webhook/status/$sha.json"
cat "$status_file"
printf '\nCURRENT=%s\n' "$(readlink -f /home/xinzhi/DataPipeline-deploy/current)"
