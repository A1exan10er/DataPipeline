import json
import urllib.request


API_URL = "http://127.0.0.1:3000/api/v1/repos/yangtianyu/DataPipeline/hooks/5"
TARGET_URL = "http://172.20.0.1:4014/gitea/datapipeline"

with open("/tmp/datapipeline-codex-webhook-admin-token", encoding="utf-8") as handle:
    token = handle.read().strip()
with open(
    "/home/xinzhi/DataPipeline-deploy/webhook/secret",
    encoding="utf-8",
) as handle:
    secret = handle.read().strip()

payload = {
    "active": True,
    "branch_filter": "refs/heads/master",
    "events": ["push"],
    "name": "DataPipeline Production CI/CD",
    "config": {
        "content_type": "json",
        "http_method": "post",
        "secret": secret,
        "url": TARGET_URL,
    },
}
request = urllib.request.Request(
    API_URL,
    data=json.dumps(payload).encode("utf-8"),
    method="PATCH",
    headers={
        "Authorization": f"token {token}",
        "Content-Type": "application/json",
    },
)
with urllib.request.urlopen(request, timeout=10) as response:
    hook = json.load(response)

if not hook["active"]:
    raise SystemExit("configured hook is inactive")
if hook["branch_filter"] != "refs/heads/master":
    raise SystemExit("configured hook has an unexpected branch filter")
if hook["events"] != ["push"]:
    raise SystemExit("configured hook has unexpected events")
if hook["config"]["url"] != TARGET_URL:
    raise SystemExit("configured hook has an unexpected target URL")

print(
    "DATAPIPELINE_HOOK_CONFIGURED",
    f"id={hook['id']}",
    f"active={hook['active']}",
    f"branch_filter={hook['branch_filter']}",
    f"events={','.join(hook['events'])}",
    f"url={hook['config']['url']}",
)
