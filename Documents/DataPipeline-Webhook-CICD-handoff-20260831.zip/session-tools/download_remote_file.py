from __future__ import annotations

import argparse
from pathlib import Path

import paramiko


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", required=True)
    parser.add_argument("--user", required=True)
    parser.add_argument("--password", required=True)
    parser.add_argument("--remote", required=True)
    parser.add_argument("--local", required=True, type=Path)
    args = parser.parse_args()

    args.local.parent.mkdir(parents=True, exist_ok=True)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        args.host,
        username=args.user,
        password=args.password,
        look_for_keys=False,
        allow_agent=False,
        timeout=15,
    )
    try:
        with client.open_sftp() as sftp:
            sftp.get(args.remote, str(args.local))
    finally:
        client.close()


if __name__ == "__main__":
    main()
