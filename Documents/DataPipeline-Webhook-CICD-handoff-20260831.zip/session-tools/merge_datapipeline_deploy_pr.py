import json
import urllib.error
import urllib.parse
import urllib.request


BASE_URL = "http://127.0.0.1:3000/api/v1"
REPOSITORY_PATH = "/repos/yangtianyu/DataPipeline"
BRANCH = "deploy/multi-robot-compat-20260831"
HEAD_SHA = "3fcc259694712ecc94dab6fc8bb4ea34026e37be"


def request(method: str, path: str, token: str, body: dict | None = None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    api_request = urllib.request.Request(
        BASE_URL + path,
        data=data,
        method=method,
        headers={
            "Authorization": f"token {token}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(api_request, timeout=20) as response:
            raw = response.read()
            return response.status, json.loads(raw) if raw else None
    except urllib.error.HTTPError as error:
        raw = error.read()
        detail = raw.decode("utf-8", "replace")[:1000]
        raise SystemExit(f"{method} {path} failed: HTTP {error.code}: {detail}")


with open(
    "/home/xinzhi/.config/datapipeline/gitea-status-token",
    encoding="utf-8",
) as handle:
    bot_token = handle.read().strip()
with open("/tmp/datapipeline-codex-merge-admin-token", encoding="utf-8") as handle:
    admin_token = handle.read().strip()

protection_path = REPOSITORY_PATH + "/branch_protections/master"
_, protection = request("GET", protection_path, admin_token)
print(
    "MASTER_PROTECTION",
    f"required_approvals={protection.get('required_approvals', 0)}",
    f"enable_status_check={protection.get('enable_status_check', False)}",
    f"enable_push={protection.get('enable_push', False)}",
)

_, pulls = request("GET", REPOSITORY_PATH + "/pulls?state=open&limit=50", bot_token)
matching = [
    pull
    for pull in pulls
    if pull["head"]["ref"] == BRANCH and pull["base"]["ref"] == "master"
]
if len(matching) > 1:
    raise SystemExit("multiple open deployment pull requests found")
if matching:
    pull = matching[0]
else:
    status, pull = request(
        "POST",
        REPOSITORY_PATH + "/pulls",
        bot_token,
        {
            "title": "Deploy multi-robot compatibility with fixed 209 Webhook CI/CD",
            "head": BRANCH,
            "base": "master",
            "body": (
                "Installs the reviewed DataPipeline product changes while CI/CD "
                "control scripts remain root-owned under /usr/local/libexec on 209."
            ),
        },
    )
    if status != 201:
        raise SystemExit(f"unexpected pull-request creation status: {status}")

if pull["head"]["sha"] != HEAD_SHA:
    raise SystemExit("pull-request head SHA changed unexpectedly")

index = pull["number"]
status, _ = request(
    "POST",
    REPOSITORY_PATH + f"/pulls/{index}/merge",
    admin_token,
    {
        "do": "fast-forward-only",
        "force_merge": True,
        "head_commit_id": HEAD_SHA,
        "delete_branch_after_merge": False,
    },
)
if status != 200:
    raise SystemExit(f"unexpected merge status: {status}")

print("DATAPIPELINE_PR_MERGED", f"index={index}", f"head={HEAD_SHA}")
