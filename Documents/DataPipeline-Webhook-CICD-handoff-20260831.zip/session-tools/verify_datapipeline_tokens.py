import urllib.error
import urllib.request


def status(path: str, token: str) -> int:
    request = urllib.request.Request(
        "http://127.0.0.1:3000/api/v1" + path,
        headers={"Authorization": f"token {token}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return response.status
    except urllib.error.HTTPError as error:
        return error.code


with open("/tmp/datapipeline-codex-admin-token", encoding="utf-8") as token_file:
    admin_token = token_file.read().strip()
with open(
    "/home/xinzhi/.config/datapipeline/gitea-status-token",
    encoding="utf-8",
) as token_file:
    bot_token = token_file.read().strip()

admin_status = status("/user", admin_token)
bot_status = status("/repos/yangtianyu/DataPipeline", bot_token)
print(f"TEMP_ADMIN_TOKEN_HTTP={admin_status}")
print(f"STATUS_BOT_REPO_HTTP={bot_status}")
if admin_status != 401 or bot_status != 200:
    raise SystemExit(1)
