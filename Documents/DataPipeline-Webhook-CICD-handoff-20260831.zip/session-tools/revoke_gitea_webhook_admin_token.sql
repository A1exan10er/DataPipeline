.bail on
BEGIN IMMEDIATE;
DELETE FROM access_token
WHERE uid = 1
  AND name = 'datapipeline-codex-webhook-20260831';
SELECT changes();
COMMIT;
