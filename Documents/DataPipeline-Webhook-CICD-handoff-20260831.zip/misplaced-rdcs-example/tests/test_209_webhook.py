from __future__ import annotations

import hashlib
import hmac
from http.client import HTTPConnection
import importlib.util
import json
from pathlib import Path
import sys
import threading
from unittest.mock import Mock, patch

import pytest


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "deployment" / "209" / "webhook.py"
SPEC = importlib.util.spec_from_file_location("rdcs_209_webhook", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
webhook = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = webhook
SPEC.loader.exec_module(webhook)


SECRET = "test-webhook-secret"


def _config(tmp_path: Path) -> object:
    return webhook.WebhookConfig(
        bind="127.0.0.1",
        port=19090,
        path="/gitea",
        secret=SECRET,
        allowed_refs=frozenset({"refs/heads/main", "refs/heads/refactor"}),
        repository="zhouwj/RobotDataCollectionSystem",
        command=("echo", "ci"),
        workdir=tmp_path,
        log_file=tmp_path / "ci.log",
    )


def _request_payload() -> bytes:
    return json.dumps(
        {
            "before": "0" * 40,
            "after": "a" * 40,
            "ref": "refs/heads/refactor",
            "repository": {"full_name": "zhouwj/RobotDataCollectionSystem"},
        }
    ).encode("utf-8")


def _headers(body: bytes, **overrides: str) -> dict[str, str]:
    signature = hmac.new(SECRET.encode("utf-8"), body, hashlib.sha256).hexdigest()
    result = {
        "X-Gitea-Event": "push",
        "X-Gitea-Signature": signature,
        "X-Gitea-Delivery": "delivery-1",
    }
    result.update(overrides)
    return result


def test_parse_valid_push_event(tmp_path: Path) -> None:
    body = _request_payload()

    event = webhook.parse_push_event(body, _headers(body), _config(tmp_path))

    assert event.before == "0" * 40
    assert event.after == "a" * 40
    assert event.ref == "refs/heads/refactor"
    assert event.repository == "zhouwj/RobotDataCollectionSystem"
    assert event.delivery_id == "delivery-1"


def test_signature_is_verified_before_payload_is_used(tmp_path: Path) -> None:
    body = _request_payload()

    with pytest.raises(webhook.WebhookRejection, match="invalid webhook signature") as error:
        webhook.parse_push_event(body, _headers(body, **{"X-Gitea-Signature": "wrong"}), _config(tmp_path))

    assert error.value.status == webhook.HTTPStatus.UNAUTHORIZED


def test_repository_and_ref_are_allowlisted(tmp_path: Path) -> None:
    body = _request_payload()
    config = _config(tmp_path)

    with pytest.raises(webhook.WebhookRejection, match="ref is not allowed"):
        webhook.parse_push_event(body, _headers(body), webhook.WebhookConfig(**{
            **config.__dict__,
            "allowed_refs": frozenset({"refs/heads/main"}),
        }))

    with pytest.raises(webhook.WebhookRejection, match="repository is not allowed"):
        webhook.parse_push_event(body, _headers(body), webhook.WebhookConfig(**{
            **config.__dict__,
            "repository": "someone/else",
        }))


def test_http_accepts_signed_push_and_starts_configured_command(tmp_path: Path) -> None:
    body = _request_payload()
    config = _config(tmp_path)
    process = Mock()
    process.wait.return_value = 0
    server = webhook.WebhookServer((config.bind, 0), config)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    try:
        connection = HTTPConnection("127.0.0.1", server.server_address[1], timeout=5)
        with patch.object(webhook.subprocess, "Popen", return_value=process) as popen:
            connection.request(
                "POST",
                "/gitea",
                body=body,
                headers={
                    **_headers(body),
                    "Content-Type": "application/json",
                    "Content-Length": str(len(body)),
                },
            )
            response = connection.getresponse()
            response_body = json.loads(response.read().decode("utf-8"))

        assert response.status == 202
        assert response_body == {
            "status": "accepted",
            "delivery_id": "delivery-1",
            "revision": "a" * 40,
        }
        popen.assert_called_once()
        assert popen.call_args.kwargs["env"]["CI_HEAD_SHA"] == "a" * 40
        assert popen.call_args.kwargs["env"]["CI_BASE_SHA"] == "0" * 40
    finally:
        connection.close()
        server.shutdown()
        server.server_close()
