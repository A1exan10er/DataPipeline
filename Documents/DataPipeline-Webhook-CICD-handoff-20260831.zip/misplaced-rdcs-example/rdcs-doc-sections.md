# 从 RobotDataCollectionSystem 移出的文档片段

## 原 `deployment/209/README.md` 新增片段

````markdown
## Optional generic Webhook receiver

The current 209 CI does not need a repository Webhook: Gitea starts
`.gitea/workflows/ci-cd.yml` directly for pushes and pull requests, and the
runner polls Gitea for jobs. `webhook.py` is only a small adapter for an
integration that explicitly needs an HTTP Webhook endpoint. It verifies the
raw-body HMAC signature, accepts only an allowlisted `push` ref and repository,
then starts the configured command asynchronously. The command is configured
by the operator; values from the payload are passed as environment variables,
not interpolated into a shell command.

Example on a Linux host:

```bash
export WEBHOOK_SECRET='replace-with-a-random-secret'
export WEBHOOK_REPOSITORY='zhouwj/RobotDataCollectionSystem'
export WEBHOOK_WORKDIR='/home/xinzhi/rdcs-worktree'
export WEBHOOK_COMMAND='bash deployment/209/verify.sh'
python3 deployment/209/webhook.py
```

Configure the Gitea hook with `POST`, `application/json`, the endpoint
`https://ci.example.com/gitea`, the same Secret, and `Push Events`. The
worktree/command must itself arrange an exact-commit checkout and isolated
execution before this adapter is used for anything beyond a minimal example;
this receiver is not part of the default 209 runner path and does not perform
deployment.
````

## 原 `docs/guides/continuous-integration.md` 新增片段

```markdown
当前仓库不依赖 Gitea Repository Webhook 来启动 209 CI：推送和 Pull Request 由
`.gitea/workflows/ci-cd.yml` 直接声明，Gitea Actions runner 轮询领取任务。只有在外部系统明确
要求 HTTP Webhook 接入时，才使用 `deployment/209/webhook.py` 这个最小接收器。它要求配置
`WEBHOOK_SECRET`，默认只接受 `refs/heads/main` 和 `refs/heads/refactor` 的 `push`，并可用
`WEBHOOK_REPOSITORY` 限定仓库；签名验证通过后异步执行固定的 `WEBHOOK_COMMAND`。它不会替代
隔离 runner，也不会自动部署；正式接入还必须让命令负责按 Webhook 的 `after` SHA 检出准确
版本、隔离执行并保存日志。
```
