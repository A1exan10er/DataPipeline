#!/usr/bin/env python3
"""Minimal Gitea push webhook receiver for an explicitly configured command."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
from pathlib import Path
import re
import shlex
import subprocess
import threading
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Mapping
from urllib.parse import urlsplit


LOGGER = logging.getLogger("rdcs.webhook")
SHA_PATTERN = re.compile(r"^[0-9a-f]{40}$")
MAX_PAYLOAD_BYTES = 1024 * 1024


class WebhookRejection(ValueError):
    """A request that must be rejected with a specific HTTP status."""

    def __init__(self, status: HTTPStatus, message: str) -> None:
        super().__init__(message)
        self.status = status


@dataclass(frozen=True)
class WebhookConfig:
    bind: str
    port: int
    path: str
    secret: str
    allowed_refs: frozenset[str]
    repository: str | None
    command: tuple[str, ...]
    workdir: Path
    log_file: Path

    @classmethod
    def from_environment(cls) -> "WebhookConfig":
        secret = os.environ.get("WEBHOOK_SECRET", "").strip()
        if not secret:
            raise RuntimeError("WEBHOOK_SECRET is required")

        raw_refs = os.environ.get(
            "WEBHOOK_ALLOWED_REFS", "refs/heads/main,refs/heads/refactor"
        )
        allowed_refs = frozenset(value.strip() for value in raw_refs.split(",") if value.strip())
        if not allowed_refs:
            raise RuntimeError("WEBHOOK_ALLOWED_REFS must contain at least one ref")

        raw_command = os.environ.get("WEBHOOK_COMMAND", "bash deployment/209/verify.sh")
        command = tuple(shlex.split(raw_command))
        if not command:
            raise RuntimeError("WEBHOOK_COMMAND must not be empty")

        try:
            port = int(os.environ.get("WEBHOOK_PORT", "19090"))
        except ValueError as exc:
            raise RuntimeError("WEBHOOK_PORT must be an integer") from exc
        if not 1 <= port <= 65535:
            raise RuntimeError("WEBHOOK_PORT must be between 1 and 65535")

        path = os.environ.get("WEBHOOK_PATH", "/gitea").strip()
        if not path.startswith("/") or path == "/":
            raise RuntimeError("WEBHOOK_PATH must be a non-root path starting with '/'")

        return cls(
            bind=os.environ.get("WEBHOOK_BIND", "127.0.0.1").strip(),
            port=port,
            path=path,
            secret=secret,
            allowed_refs=allowed_refs,
            repository=os.environ.get("WEBHOOK_REPOSITORY", "").strip() or None,
            command=command,
            workdir=Path(os.environ.get("WEBHOOK_WORKDIR", ".")).resolve(),
            log_file=Path(
                os.environ.get("WEBHOOK_LOG_FILE", "/tmp/rdcs-webhook-ci.log")
            ).resolve(),
        )


@dataclass(frozen=True)
class PushEvent:
    before: str
    after: str
    ref: str
    repository: str
    delivery_id: str


def _header(headers: Mapping[str, str], name: str) -> str:
    wanted = name.casefold()
    for key, value in headers.items():
        if key.casefold() == wanted:
            return value.strip()
    return ""


def verify_signature(body: bytes, signature: str, secret: str) -> bool:
    """Verify Gitea's lowercase, unprefixed HMAC-SHA256 signature."""

    expected = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    return bool(signature) and hmac.compare_digest(expected, signature.strip().lower())


def parse_push_event(
    body: bytes,
    headers: Mapping[str, str],
    config: WebhookConfig,
) -> PushEvent:
    if _header(headers, "X-Gitea-Event") != "push":
        raise WebhookRejection(HTTPStatus.BAD_REQUEST, "only push events are supported")

    if not verify_signature(body, _header(headers, "X-Gitea-Signature"), config.secret):
        raise WebhookRejection(HTTPStatus.UNAUTHORIZED, "invalid webhook signature")

    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise WebhookRejection(HTTPStatus.BAD_REQUEST, "payload must be valid UTF-8 JSON") from exc
    if not isinstance(payload, dict):
        raise WebhookRejection(HTTPStatus.BAD_REQUEST, "payload must be a JSON object")

    ref = payload.get("ref")
    before = payload.get("before")
    after = payload.get("after")
    repository_data = payload.get("repository")
    repository = repository_data.get("full_name") if isinstance(repository_data, dict) else None
    if not all(isinstance(value, str) for value in (ref, before, after, repository)):
        raise WebhookRejection(HTTPStatus.BAD_REQUEST, "push payload is missing required fields")
    if ref not in config.allowed_refs:
        raise WebhookRejection(HTTPStatus.FORBIDDEN, "ref is not allowed")
    if config.repository is not None and repository != config.repository:
        raise WebhookRejection(HTTPStatus.FORBIDDEN, "repository is not allowed")
    if not SHA_PATTERN.fullmatch(after):
        raise WebhookRejection(HTTPStatus.BAD_REQUEST, "after must be a 40-character commit SHA")
    if before != "0" * 40 and not SHA_PATTERN.fullmatch(before):
        raise WebhookRejection(HTTPStatus.BAD_REQUEST, "before must be a commit SHA")

    return PushEvent(
        before=before,
        after=after,
        ref=ref,
        repository=repository,
        delivery_id=_header(headers, "X-Gitea-Delivery") or "unknown",
    )


class WebhookServer(ThreadingHTTPServer):
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], config: WebhookConfig) -> None:
        super().__init__(address, WebhookHandler)
        self.config = config
        self.trigger_lock = threading.Lock()
        self.command_running = False

    def start_command(self, event: PushEvent) -> None:
        self.config.log_file.parent.mkdir(parents=True, exist_ok=True)
        child_environment = os.environ.copy()
        child_environment.update(
            {
                "CI_BASE_SHA": event.before,
                "CI_HEAD_SHA": event.after,
                "CI_EVENT_DELIVERY_ID": event.delivery_id,
                "GITEA_REPOSITORY": event.repository,
                "GITEA_REF": event.ref,
            }
        )
        log_handle = self.config.log_file.open("ab")
        try:
            process = subprocess.Popen(
                list(self.config.command),
                cwd=self.config.workdir,
                env=child_environment,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                start_new_session=os.name != "nt",
            )
        except BaseException:
            log_handle.close()
            raise
        log_handle.close()
        threading.Thread(
            target=self._wait_for_command,
            args=(process, event),
            daemon=True,
            name="webhook-ci-result",
        ).start()

    def _wait_for_command(self, process: subprocess.Popen[bytes], event: PushEvent) -> None:
        try:
            return_code = process.wait()
            LOGGER.info(
                "CI command finished: delivery=%s revision=%s return_code=%s",
                event.delivery_id,
                event.after,
                return_code,
            )
        finally:
            with self.trigger_lock:
                self.command_running = False


class WebhookHandler(BaseHTTPRequestHandler):
    server: WebhookServer

    def do_POST(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
        config = self.server.config
        if urlsplit(self.path).path != config.path:
            self._send_json(HTTPStatus.NOT_FOUND, {"error": "not found"})
            return

        raw_length = self.headers.get("Content-Length")
        try:
            content_length = int(raw_length) if raw_length is not None else -1
        except ValueError:
            content_length = -1
        if content_length < 0:
            self._send_json(HTTPStatus.LENGTH_REQUIRED, {"error": "content length is required"})
            return
        if content_length > MAX_PAYLOAD_BYTES:
            self._send_json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, {"error": "payload is too large"})
            return

        body = self.rfile.read(content_length)
        if len(body) != content_length:
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": "incomplete payload"})
            return

        try:
            event = parse_push_event(body, self.headers, config)
        except WebhookRejection as exc:
            self._send_json(exc.status, {"error": str(exc)})
            return

        with self.server.trigger_lock:
            if self.server.command_running:
                self._send_json(HTTPStatus.ACCEPTED, {"status": "already_running"})
                return
            self.server.command_running = True
            try:
                self.server.start_command(event)
            except OSError as exc:
                self.server.command_running = False
                LOGGER.exception("could not start CI command")
                self._send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})
                return

        self._send_json(
            HTTPStatus.ACCEPTED,
            {"status": "accepted", "delivery_id": event.delivery_id, "revision": event.after},
        )

    def do_GET(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
        self._send_json(HTTPStatus.METHOD_NOT_ALLOWED, {"error": "POST is required"})

    def log_message(self, format: str, *args: object) -> None:
        LOGGER.info("%s - %s", self.address_string(), format % args)

    def _send_json(self, status: HTTPStatus, payload: dict[str, str]) -> None:
        encoded = json.dumps(payload, ensure_ascii=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)


def main() -> int:
    try:
        config = WebhookConfig.from_environment()
    except RuntimeError as exc:
        print(f"configuration error: {exc}")
        return 2

    logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO").upper())
    server = WebhookServer((config.bind, config.port), config)
    LOGGER.info("listening on %s:%s%s", config.bind, config.port, config.path)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        LOGGER.info("stopping")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
