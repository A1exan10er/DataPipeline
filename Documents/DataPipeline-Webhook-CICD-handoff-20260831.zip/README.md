# DataPipeline Webhook CI/CD 会话交接包

本目录保存 2026-08-31 会话中与 DataPipeline Webhook CI/CD 有关、但不属于
`RobotDataCollectionSystem` 仓库的文件和操作记录。可将整个目录移动到无主题会话。

## 最终结果

- Gitea 仓库：`yangtianyu/DataPipeline`
- 最初审查分支：`deploy/multi-robot-compat-20260831`
- 用户最初指定提交：`4be71c0050d81356d7b6b2ad8ef250b38420ed7f`
- 最终 master：`3fcc259694712ecc94dab6fc8bb4ea34026e37be`
- Webhook ID：`5`
- Webhook URL：`http://172.20.0.1:4014/gitea/datapipeline`
- 触发范围：仅 `yangtianyu/DataPipeline`、仅 `refs/heads/master`、仅 push
- 最终 CI：`163 passed, 7 skipped`
- 最终状态：`success / completed`
- 当前 release：`/home/xinzhi/DataPipeline-deploy/releases/3fcc259694712ecc94dab6fc8bb4ea34026e37be`

## 目录内容

- `final-source/`：从 209 上 Gitea 的最终 master 导出的 `deploy/` 源码和
  `Werkzeuge/check_task_device_reference.py`。
- `records/`：最终源码压缩包、SHA 对应的 CI/CD 日志和状态 JSON。
- `session-tools/`：本次会话使用的一次性检查、导出、API 和补丁工具。它们用于追溯，
  不是生产入口；部分工具会操作 Gitea，请勿直接重放。
- `reference/`：用户提供的 `webhook.py` 和 Gitea Webhook 配置截图。
- `misplaced-rdcs-example/`：此前误放入 RobotDataCollectionSystem 的通用 Webhook 示例、
  测试和文档片段，现已从该仓库移出。

## 209 上的生产入口

以下文件仍保留在 209 上，不应从服务器移动；本目录只保存其源码副本：

```text
/usr/local/libexec/datapipeline-webhook-server
/usr/local/libexec/datapipeline-webhook-job
/usr/local/libexec/datapipeline-ci-verify
/usr/local/libexec/datapipeline-package-release
/usr/local/libexec/datapipeline-webhook-deploy-v1
/usr/local/libexec/datapipeline-artifact-verifier
/usr/local/libexec/datapipeline-deploy-status-server
/usr/local/libexec/datapipeline-webhook-safety-test
```

这些入口当前均为 `root:root 0755`。Webhook 只执行这些固定脚本，不执行 DataPipeline
工作树中的 CI/CD 控制脚本。产品源码仅作为被测试和被打包对象。

## CI/CD 流程

```text
Gitea master push
  → HMAC、仓库和分支校验
  → 从 209 本地 bare repository 检出精确 SHA
  → Python 3.10 隔离容器执行测试
  → 构建 Python 3.10 离线 wheelhouse
  → 生成并校验 release artifact
  → 固定部署器进行部署前检查
  → 原子切换 current
  → 重启并检查 Dashboard 和 Event Listener
  → 回写 Gitea commit status
```

容器使用只读根文件系统、丢弃 capabilities、启用 `no-new-privileges`，且不能控制宿主机
systemd。测试所需的 `systemctl` 名称由只读 `/usr/bin/false` 占位。

## 主要变更提交

```text
4be71c0050d81356d7b6b2ad8ef250b38420ed7f  初始固定 Webhook CI/CD 方案
ac9236da791fb6f9c8dcb4ffae6765fce75a9801  固定 209 控制脚本并加强权限检查
eca8126b40517910477a3b433f36a88d0a3e43a0  产品 CI 与仓库内控制文件解耦
3e64ff1318706f46183d013138462139fbb3df61  允许 pytest 临时可执行 fixture
5e0b4736594dad152d8c7efa099d0f993bf991a6  使用 Python 3.10 解析生产 wheelhouse
bd69f6c58a17a2098e5ec1dfe0ececedcf791954  增加无宿主权限的 systemctl 测试占位
3fcc259694712ecc94dab6fc8bb4ea34026e37be  正确导出固定 DCS 配置并完成部署
```

受保护 master 通过 Gitea PR #24、#25、#26、#27 更新。所有一次性管理员令牌均已撤销。

## 运行时数据与敏感信息

以下敏感文件没有复制到本交接包：

```text
/home/xinzhi/DataPipeline-deploy/webhook/secret
/home/xinzhi/.config/datapipeline/gitea-status-token
/home/xinzhi/.qa_task_db_env
/home/xinzhi/DataPipeline/dcp-sdk/dcs_config.json
```

旧版本和迁移期间产生的数据没有删除，保留在 209 的隐藏 legacy/orphaned release 目录中。

## 最终服务状态

会话结束前已确认以下 user services 全部为 `active`：

```text
datapipeline-webhook.service
datapipeline-deploy-status.service
datapipeline-dashboard.service
datapipeline-event-listener.service
```

端口为 Webhook `172.20.0.1:4014`、状态服务 `0.0.0.0:4015`、Dashboard
`0.0.0.0:4131`。
