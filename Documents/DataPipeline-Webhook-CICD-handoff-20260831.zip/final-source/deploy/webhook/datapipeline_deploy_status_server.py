#!/usr/bin/env python3
"""Read-only, LAN-scoped DataPipeline deployment status and log viewer."""

from __future__ import annotations

import html
import ipaddress
import json
import os
import re
import stat
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit


BIND_HOST = os.environ.get("DATAPIPELINE_STATUS_BIND_HOST", "0.0.0.0")
BIND_PORT = int(os.environ.get("DATAPIPELINE_STATUS_BIND_PORT", "4015"))
STATUS_ROOT = Path(
    os.environ.get(
        "DATAPIPELINE_STATUS_ROOT",
        "/home/xinzhi/DataPipeline-deploy/webhook/status",
    )
)
LOG_ROOT = Path(
    os.environ.get(
        "DATAPIPELINE_LOG_ROOT",
        "/home/xinzhi/DataPipeline-deploy/webhook/logs",
    )
)
MAX_STATE_BYTES = 64 * 1024
MAX_LOG_BYTES = 256 * 1024
SHA_RE = re.compile(r"^[0-9a-f]{40}$")
STATUS_PATH_RE = re.compile(r"^/deploy-status/([0-9a-f]{40})(\.json)?$")
ALLOWED_NETWORKS = (
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("192.168.50.0/24"),
)
SECRET_PATTERNS = (
    (
        re.compile(r"(?i)(authorization\s*:\s*(?:token|bearer)\s+)[^\s\"']+"),
        r"\1[REDACTED]",
    ),
    (
        re.compile(
            r"(?i)\b((?:api[_-]?token|access[_-]?token|password|passwd|secret)\s*[=:]\s*)"
            r"[^\s\"']+"
        ),
        r"\1[REDACTED]",
    ),
    (re.compile(r"(?i)(https?://[^\s:/]+:)[^@\s/]+(@)"), r"\1[REDACTED]\2"),
)


def client_is_allowed(address: str) -> bool:
    try:
        client = ipaddress.ip_address(address)
    except ValueError:
        return False
    return any(client in network for network in ALLOWED_NETWORKS)


def safe_file(root: Path, name: str, maximum: int) -> bytes | None:
    if not SHA_RE.fullmatch(name.removesuffix(".json").removesuffix(".log")):
        return None
    path = root / name
    try:
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(path, flags)
        with os.fdopen(descriptor, "rb") as handle:
            metadata = os.fstat(handle.fileno())
            if not stat.S_ISREG(metadata.st_mode):
                return None
            if metadata.st_size > maximum:
                handle.seek(-maximum, os.SEEK_END)
            return handle.read(maximum)
    except (OSError, ValueError):
        return None


def read_state(sha: str) -> dict[str, Any]:
    raw = safe_file(STATUS_ROOT, f"{sha}.json", MAX_STATE_BYTES)
    if raw is None:
        return {
            "sha": sha,
            "state": "unknown",
            "stage": "waiting",
            "description": "No deployment state has been recorded yet.",
            "updated_at": "",
        }
    try:
        state = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        state = {}
    if not isinstance(state, dict):
        state = {}
    return {
        "sha": sha,
        "state": str(state.get("state", "unknown"))[:32],
        "stage": str(state.get("stage", "unknown"))[:64],
        "description": str(state.get("description", "State file is invalid."))[:500],
        "updated_at": str(state.get("updated_at", ""))[:64],
    }


def sanitize_log(value: str) -> str:
    sanitized = value
    for pattern, replacement in SECRET_PATTERNS:
        sanitized = pattern.sub(replacement, sanitized)
    return sanitized


def read_log_tail(sha: str) -> str:
    raw = safe_file(LOG_ROOT, f"{sha}.log", MAX_LOG_BYTES)
    if raw is None:
        return "No deployment log is available yet."
    text = raw.decode("utf-8", errors="replace")
    return sanitize_log("\n".join(text.splitlines()[-400:]))


def status_document(sha: str) -> bytes:
    state = read_state(sha)
    log_text = read_log_tail(sha)
    refresh = (
        '<meta http-equiv="refresh" content="5">'
        if state["state"] in {"pending", "running", "deploying", "unknown"}
        else ""
    )
    document = f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">{refresh}
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DataPipeline 部署状态</title>
<style>
body{{font:15px/1.55 system-ui,sans-serif;max-width:1100px;margin:32px auto;padding:0 20px;color:#18202a}}
.card{{border:1px solid #d6dbe1;border-radius:10px;padding:18px;margin-bottom:18px;background:#fff}}
dt{{font-weight:650}}dd{{margin:0 0 8px;overflow-wrap:anywhere}}
pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#111820;color:#dce7f2;padding:16px;border-radius:8px;max-height:65vh;overflow:auto}}
.state{{font-weight:700}}small{{color:#65717e}}
</style></head><body>
<h1>DataPipeline 部署状态</h1>
<section class="card"><dl>
<dt>Commit</dt><dd><code>{html.escape(sha)}</code></dd>
<dt>状态</dt><dd class="state">{html.escape(state['state'])}</dd>
<dt>阶段</dt><dd>{html.escape(state['stage'])}</dd>
<dt>说明</dt><dd>{html.escape(state['description'])}</dd>
<dt>更新时间</dt><dd>{html.escape(state['updated_at']) or '—'}</dd>
</dl><small>执行中页面每 5 秒自动刷新。这里只显示脱敏后的最后 400 行日志。</small></section>
<section class="card"><h2>部署日志</h2><pre>{html.escape(log_text)}</pre></section>
</body></html>"""
    return document.encode("utf-8")


class StatusHandler(BaseHTTPRequestHandler):
    server_version = "DataPipelineStatus/1"

    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        if not client_is_allowed(self.client_address[0]):
            self._send(403, b"Forbidden\n", "text/plain; charset=utf-8")
            return
        path = urlsplit(self.path).path
        if path == "/healthz":
            self._send(200, b"ok\n", "text/plain; charset=utf-8")
            return
        match = STATUS_PATH_RE.fullmatch(path)
        if match is None:
            self._send(404, b"Not found\n", "text/plain; charset=utf-8")
            return
        sha, json_suffix = match.groups()
        if json_suffix:
            body = (json.dumps(read_state(sha), ensure_ascii=False) + "\n").encode("utf-8")
            self._send(200, body, "application/json; charset=utf-8")
            return
        self._send(200, status_document(sha), "text/html; charset=utf-8")

    def log_message(self, format: str, *args: object) -> None:
        super().log_message(format, *args)


def main() -> None:
    server = ThreadingHTTPServer((BIND_HOST, BIND_PORT), StatusHandler)
    server.serve_forever()


if __name__ == "__main__":
    main()
