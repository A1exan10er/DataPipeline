#!/usr/bin/env bash
set -euo pipefail

# This test deliberately avoids an in-scope push payload, so it cannot start a
# build or deployment. It verifies health, signature rejection, and scope.

readonly EXPECTED_USER="xinzhi"
readonly WEBHOOK_URL="${DATAPIPELINE_WEBHOOK_URL:-http://172.20.0.1:4014}"
readonly DEPLOY_STATUS_URL="${DATAPIPELINE_DEPLOY_STATUS_URL:-http://127.0.0.1:4015}"
readonly SECRET_FILE="${DATAPIPELINE_WEBHOOK_SECRET_FILE:-/home/xinzhi/DataPipeline-deploy/webhook/secret}"

if [[ "$(id -un)" != "$EXPECTED_USER" ]]; then
  echo "Run this safety test as $EXPECTED_USER." >&2
  exit 1
fi
for command_name in curl python3; do
  command -v "$command_name" >/dev/null 2>&1 || {
    echo "Missing safety-test prerequisite: $command_name" >&2
    exit 1
  }
done
if [[ ! -f "$SECRET_FILE" || -L "$SECRET_FILE" ]]; then
  echo "Missing webhook secret: $SECRET_FILE" >&2
  exit 1
fi

curl --fail --silent --show-error --max-time 5 "$WEBHOOK_URL/healthz" >/dev/null
curl --fail --silent --show-error --max-time 5 "$DEPLOY_STATUS_URL/healthz" >/dev/null

invalid_status_code="$(curl --silent --show-error --output /dev/null --write-out '%{http_code}' \
  --max-time 5 "$DEPLOY_STATUS_URL/deploy-status/../../etc/passwd")"
if [[ "$invalid_status_code" != "404" ]]; then
  echo "Expected an invalid deployment-status path to return 404, got $invalid_status_code." >&2
  exit 1
fi

payload='{"ref":"refs/heads/master","after":"0000000000000000000000000000000000000001","repository":{"full_name":"outside/scope"}}'
invalid_code="$(curl --silent --show-error --output /dev/null --write-out '%{http_code}' \
  --max-time 5 --request POST --header 'X-Gitea-Event: push' \
  --header 'X-Gitea-Signature: invalid' --data-binary "$payload" \
  "$WEBHOOK_URL/gitea/datapipeline")"
if [[ "$invalid_code" != "401" ]]; then
  echo "Expected an invalid signature to return 401, got $invalid_code." >&2
  exit 1
fi

signature="$(python3 - "$SECRET_FILE" "$payload" <<'PY'
import hashlib
import hmac
import sys

with open(sys.argv[1], "rb") as handle:
    secret = handle.read().strip()
print(hmac.new(secret, sys.argv[2].encode("utf-8"), hashlib.sha256).hexdigest())
PY
)"
ignored_code="$(curl --silent --show-error --output /dev/null --write-out '%{http_code}' \
  --max-time 5 --request POST --header 'X-Gitea-Event: push' \
  --header "X-Gitea-Signature: $signature" --data-binary "$payload" \
  "$WEBHOOK_URL/gitea/datapipeline")"
if [[ "$ignored_code" != "202" ]]; then
  echo "Expected an out-of-scope repository to return 202, got $ignored_code." >&2
  exit 1
fi

echo "Webhook and read-only deployment-status safety checks passed without starting a build or deployment."
