#!/usr/bin/env python3
"""Validate and extract a fixed-format DataPipeline release artifact."""

from __future__ import annotations

import argparse
import hashlib
import json
import tarfile
from pathlib import Path, PurePosixPath


REPOSITORY = "yangtianyu/DataPipeline"
ARTIFACT_FORMAT = "datapipeline-release-v1"
REQUIRED_PATHS = (
    "QA_Pipeline/scripts/qa_control_dashboard.py",
    "QA_Pipeline/scripts/event_listener_control.sh",
    "Werkzeuge/listen_episode_verified.py",
    "Werkzeuge/check_dcs_config.py",
    "Werkzeuge/check_event_listener_health.py",
    "Werkzeuge/check_task_device_reference.py",
    "dcp-sdk/dcs_sdk/config.py",
)


def safe_extract(archive_path: Path, destination: Path) -> None:
    seen: set[PurePosixPath] = set()
    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        for member in members:
            path = PurePosixPath(member.name)
            normalized = PurePosixPath(*("" if part == "." else part for part in path.parts))
            if path.is_absolute() or ".." in path.parts:
                raise ValueError(f"unsafe release path: {member.name}")
            if not (member.isfile() or member.isdir()):
                raise ValueError(f"unsupported release entry type: {member.name}")
            if normalized in seen and normalized.parts:
                raise ValueError(f"duplicate release path: {member.name}")
            seen.add(normalized)
        archive.extractall(destination, members=members)


def validate_release(destination: Path, target_sha: str) -> dict[str, object]:
    marker = destination / ".datapipeline-release-sha"
    if not marker.is_file() or marker.read_text(encoding="utf-8").strip() != target_sha:
        raise ValueError("release marker does not match the requested commit")
    manifest_path = destination / "release-manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid release manifest: {exc}") from exc
    if not isinstance(manifest, dict):
        raise ValueError("release manifest must be an object")
    if manifest.get("repository") != REPOSITORY:
        raise ValueError("unexpected release repository")
    if manifest.get("commit") != target_sha:
        raise ValueError("release manifest commit mismatch")
    if manifest.get("artifact_format") != ARTIFACT_FORMAT:
        raise ValueError("unsupported release artifact format")
    for required_path in REQUIRED_PATHS:
        if not (destination / required_path).is_file():
            raise ValueError(f"release artifact is missing {required_path}")
    outputs = destination / "outputs"
    if outputs.exists() or outputs.is_symlink():
        raise ValueError("release artifact must not provide the persistent outputs path")

    wheel_root = destination / "wheels"
    wheels = manifest.get("wheels")
    if not isinstance(wheels, list) or not wheels:
        raise ValueError("release manifest has no wheels")
    declared: set[str] = set()
    for entry in wheels:
        if not isinstance(entry, dict):
            raise ValueError("invalid wheel manifest entry")
        name = str(entry.get("name") or "")
        if Path(name).name != name or not name.endswith(".whl") or name in declared:
            raise ValueError("invalid wheel name in manifest")
        declared.add(name)
        wheel = wheel_root / name
        if not wheel.is_file() or wheel.is_symlink():
            raise ValueError(f"missing or unsafe release wheel: {name}")
        digest = hashlib.sha256(wheel.read_bytes()).hexdigest()
        if digest != entry.get("sha256"):
            raise ValueError(f"release wheel hash mismatch: {name}")
    actual = {wheel.name for wheel in wheel_root.glob("*.whl") if wheel.is_file()}
    if actual != declared:
        raise ValueError("release wheelhouse does not match the manifest")
    return manifest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--destination", required=True, type=Path)
    parser.add_argument("--sha", required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if len(args.sha) != 40 or any(ch not in "0123456789abcdef" for ch in args.sha):
        raise SystemExit("A full lowercase 40-character commit SHA is required.")
    if any(args.destination.iterdir()):
        raise SystemExit("Artifact destination must be empty.")
    try:
        safe_extract(args.archive, args.destination)
        validate_release(args.destination, args.sha)
    except (OSError, ValueError, tarfile.TarError) as exc:
        raise SystemExit(str(exc)) from exc
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
