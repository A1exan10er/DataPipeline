#!/usr/bin/env bash
set -Eeuo pipefail

# Maintainer-owned production entry point. It consumes only a locally built,
# checksum-verified artifact selected by its exact DataPipeline commit SHA.

readonly EXPECTED_USER="xinzhi"
readonly DEPLOY_ROOT="/home/xinzhi/DataPipeline-deploy"
readonly PERSISTENT_ROOT="/home/xinzhi/DataPipeline"
readonly PERSISTENT_OUTPUTS="$PERSISTENT_ROOT/outputs"
readonly DCS_CONFIG_FILE="$PERSISTENT_ROOT/dcp-sdk/dcs_config.json"
readonly TASK_DB_ENV_FILE="/home/xinzhi/.qa_task_db_env"
readonly SYSTEMD_USER_DIR="/home/xinzhi/.config/systemd/user"
readonly RELEASES_DIR="$DEPLOY_ROOT/releases"
readonly ARTIFACTS_DIR="$DEPLOY_ROOT/artifacts"
readonly CURRENT_LINK="$DEPLOY_ROOT/current"
readonly SWITCH_LOCK="$DEPLOY_ROOT/release-switch.lock"
readonly DASHBOARD_SERVICE="datapipeline-dashboard.service"
readonly LISTENER_SERVICE="datapipeline-event-listener.service"
readonly LISTENER_PHASES="1,2,3,7"
readonly EVENT_QUEUE_NAME="qa_pipeline.listen_episode_verified.v2"
readonly ARTIFACT_VERIFIER="/usr/local/libexec/datapipeline-artifact-verifier"
export DCS_CONFIG_FILE

target_sha=""
artifact_argument=""

usage() {
  cat >&2 <<'EOF'
Usage: datapipeline-webhook-deploy-v1 \
  --sha FULL_40_CHARACTER_COMMIT_SHA \
  --artifact /home/xinzhi/DataPipeline-deploy/artifacts/datapipeline-SHA.tar.gz
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --sha) target_sha="${2:-}"; shift 2 ;;
    --artifact) artifact_argument="${2:-}"; shift 2 ;;
    *) usage; exit 2 ;;
  esac
done

if [[ "$(id -un)" != "$EXPECTED_USER" ]]; then
  echo "Deployment must run as $EXPECTED_USER." >&2
  exit 1
fi
if [[ ! "$target_sha" =~ ^[0-9a-f]{40}$ ]]; then
  echo "A full lowercase 40-character commit SHA is required." >&2
  exit 2
fi
if [[ -z "$artifact_argument" ]]; then
  usage
  exit 2
fi

umask 077
for command_name in awk curl flock grep id ln mkdir mv python3 readlink rm sha256sum sleep ss stat systemctl unlink; do
  command -v "$command_name" >/dev/null 2>&1 || {
    echo "Missing deployment prerequisite: $command_name" >&2
    exit 1
  }
done

python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("Python 3.10 or newer is required.")
PY

require_private_file() {
  local path="$1"
  local label="$2"
  if [[ ! -f "$path" || -L "$path" ]]; then
    echo "Missing protected $label: $path" >&2
    exit 1
  fi
  if [[ "$(stat -c '%U' "$path")" != "$EXPECTED_USER" ]]; then
    echo "$label must be owned by $EXPECTED_USER." >&2
    exit 1
  fi
  local mode value
  mode="$(stat -c '%a' "$path")"
  value=$((8#$mode))
  if (( (value & 8#077) != 0 )); then
    echo "$label must not be accessible by group or other users." >&2
    exit 1
  fi
}

require_private_directory() {
  local path="$1"
  local label="$2"
  if [[ ! -d "$path" || -L "$path" ]]; then
    echo "Missing protected $label directory: $path" >&2
    exit 1
  fi
  if [[ "$(stat -c '%U' "$path")" != "$EXPECTED_USER" ]]; then
    echo "$label directory must be owned by $EXPECTED_USER." >&2
    exit 1
  fi
  local mode value
  mode="$(stat -c '%a' "$path")"
  value=$((8#$mode))
  if (( (value & 8#077) != 0 )); then
    echo "$label directory must not be accessible by group or other users." >&2
    exit 1
  fi
}

require_private_file "$DCS_CONFIG_FILE" "production DCS configuration"
require_private_file "$TASK_DB_ENV_FILE" "task database environment"
require_private_directory "$DEPLOY_ROOT" "deployment root"
require_private_directory "$RELEASES_DIR" "releases"
require_private_directory "$ARTIFACTS_DIR" "artifacts"
require_private_directory "$PERSISTENT_OUTPUTS" "persistent outputs"
if [[ ! -f "$ARTIFACT_VERIFIER" || -L "$ARTIFACT_VERIFIER" || "$(stat -c '%u' "$ARTIFACT_VERIFIER")" != "0" ]]; then
  echo "Missing or unsafe fixed artifact verifier: $ARTIFACT_VERIFIER" >&2
  exit 1
fi

exec 8>"$SWITCH_LOCK"
if ! flock -w 300 8; then
  echo "Timed out waiting for another release switch." >&2
  exit 1
fi

verify_file_hash() {
  local path="$1"
  local expected="$2"
  local actual
  if [[ ! -f "$path" || -L "$path" ]]; then
    echo "Missing approved deployment-control file: $path" >&2
    return 1
  fi
  actual="$(sha256sum "$path" | awk '{print $1}')"
  if [[ "$actual" != "$expected" ]]; then
    echo "Unapproved deployment-control file: $path" >&2
    return 1
  fi
}

verify_file_hash "$SYSTEMD_USER_DIR/$DASHBOARD_SERVICE" \
  "1b28aa4b8bf74028b0b8ed403abbdfb14fd0b0d48dd76b94fde6d6f4ef45f1ca"
verify_file_hash "$SYSTEMD_USER_DIR/$LISTENER_SERVICE" \
  "e42c4458baf7ba93dbeb7519b15cfe599da596c75f4ec8f0a1594a0568a593ee"
systemctl --user is-enabled --quiet "$DASHBOARD_SERVICE"

expected_artifact="$ARTIFACTS_DIR/datapipeline-$target_sha.tar.gz"
if [[ ! -f "$artifact_argument" || -L "$artifact_argument" ]]; then
  echo "Missing or unsafe release artifact: $artifact_argument" >&2
  exit 1
fi
artifact_path="$(readlink -f "$artifact_argument")"
if [[ "$artifact_path" != "$expected_artifact" ]]; then
  echo "The release artifact is outside the fixed artifact path." >&2
  exit 1
fi
checksum_path="$artifact_path.sha256"
require_private_file "$artifact_path" "release artifact"
require_private_file "$checksum_path" "release checksum"

artifact_name="datapipeline-$target_sha.tar.gz"
expected_hash="$(awk -v name="$artifact_name" '$2 == name {print $1; exit}' "$checksum_path")"
if [[ ! "$expected_hash" =~ ^[0-9a-f]{64}$ ]]; then
  echo "The artifact checksum file is invalid." >&2
  exit 1
fi
actual_hash="$(sha256sum "$artifact_path" | awk '{print $1}')"
if [[ "$actual_hash" != "$expected_hash" ]]; then
  echo "The local artifact SHA-256 does not match." >&2
  exit 1
fi

release_dir="$RELEASES_DIR/$target_sha"
temporary_release="$RELEASES_DIR/.$target_sha.tmp.$$"
previous_release=""
switched=0
services_stopped=0
listener_was_active=0
listener_was_desired=0

if systemctl --user is-active --quiet "$LISTENER_SERVICE" 2>/dev/null; then
  listener_was_active=1
  listener_was_desired=1
fi
if [[ -f "$PERSISTENT_OUTPUTS/event_listener/control/listener.enabled" ]]; then
  listener_was_desired=1
fi
if [[ -L "$CURRENT_LINK" ]]; then
  previous_release="$(readlink -f "$CURRENT_LINK")"
fi

restore_services() {
  systemctl --user restart "$DASHBOARD_SERVICE" >/dev/null 2>&1 || true
  if [[ "$listener_was_active" == "1" ]]; then
    systemctl --user enable "$LISTENER_SERVICE" >/dev/null 2>&1 || true
    systemctl --user restart "$LISTENER_SERVICE" >/dev/null 2>&1 || true
  fi
}

finish_or_rollback() {
  local status=$?
  if [[ -d "$temporary_release" ]]; then
    rm -rf -- "$temporary_release"
  fi
  if [[ "$status" != "0" ]]; then
    echo "Deployment failed; restoring the previous DataPipeline release." >&2
    if [[ "$services_stopped" == "1" || "$switched" == "1" ]]; then
      systemctl --user stop "$LISTENER_SERVICE" "$DASHBOARD_SERVICE" >/dev/null 2>&1 || true
      if [[ "$switched" == "1" ]]; then
        if [[ -n "$previous_release" && -d "$previous_release" ]]; then
          rollback_link="$DEPLOY_ROOT/.current.rollback.$$"
          ln -s "$previous_release" "$rollback_link"
          mv -Tf "$rollback_link" "$CURRENT_LINK"
        elif [[ -L "$CURRENT_LINK" ]]; then
          unlink "$CURRENT_LINK"
        fi
      fi
      if [[ -L "$CURRENT_LINK" ]]; then
        restore_services
      fi
    fi
  fi
  exit "$status"
}
trap finish_or_rollback EXIT

if [[ ! -d "$release_dir" ]]; then
  mkdir "$temporary_release"
  /usr/bin/python3 "$ARTIFACT_VERIFIER" \
    --archive "$artifact_path" \
    --destination "$temporary_release" \
    --sha "$target_sha"

  ln -s "$PERSISTENT_OUTPUTS" "$temporary_release/outputs"
  /usr/bin/python3 -m venv "$temporary_release/datapipeline-env"
  if ! compgen -G "$temporary_release/wheels/*.whl" >/dev/null; then
    echo "Release artifact contains no Python wheels." >&2
    exit 1
  fi
  PIP_CONFIG_FILE=/dev/null "$temporary_release/datapipeline-env/bin/python" -m pip \
    install --disable-pip-version-check --no-input --require-virtualenv \
    --no-index --find-links "$temporary_release/wheels" \
    "$temporary_release"/wheels/*.whl
  rm -rf -- "$temporary_release/wheels"
  "$temporary_release/datapipeline-env/bin/python" -m compileall -q \
    "$temporary_release/QA_Pipeline/scripts" \
    "$temporary_release/Werkzeuge" \
    "$temporary_release/data_slow_movement_detection/scripts"
  mv "$temporary_release" "$release_dir"
fi

if [[ ! -f "$release_dir/.datapipeline-release-sha" || "$(<"$release_dir/.datapipeline-release-sha")" != "$target_sha" ]]; then
  echo "Existing release marker does not match the requested commit." >&2
  exit 1
fi
if [[ ! -x "$release_dir/datapipeline-env/bin/python" ]]; then
  echo "Existing release has no usable Python runtime." >&2
  exit 1
fi
if [[ "$(readlink -f "$release_dir/outputs")" != "$PERSISTENT_OUTPUTS" ]]; then
  echo "Existing release does not use the protected persistent outputs directory." >&2
  exit 1
fi

# Both checks are read-only and finish before any running service is stopped.
set -a
# shellcheck disable=SC1090
source "$TASK_DB_ENV_FILE"
set +a
"$release_dir/datapipeline-env/bin/python" \
  "$release_dir/Werkzeuge/check_dcs_config.py" \
  --dc-root "$release_dir/dcp-sdk" \
  --qa-root "$release_dir/QA_Pipeline" \
  --phases "$LISTENER_PHASES"
"$release_dir/datapipeline-env/bin/python" \
  "$release_dir/Werkzeuge/check_task_device_reference.py" \
  --qa-root "$release_dir/QA_Pipeline"

services_stopped=1
systemctl --user stop "$LISTENER_SERVICE" >/dev/null 2>&1 || true
systemctl --user stop "$DASHBOARD_SERVICE"

if ! /usr/bin/python3 - <<'PY'
from pathlib import Path

listeners = []
for path in Path("/proc").iterdir():
    if not path.name.isdigit():
        continue
    try:
        args = [part for part in (path / "cmdline").read_bytes().split(b"\0") if part]
    except OSError:
        continue
    decoded = [part.decode("utf-8", "replace") for part in args]
    if any("Werkzeuge/listen_episode_verified.py" in arg for arg in decoded) and "serve" in decoded:
        listeners.append((path.name, " ".join(decoded)))
if listeners:
    for pid, command in listeners:
        print(f"Unmanaged listener remains: PID={pid}, command={command}")
    raise SystemExit(1)
PY
then
  echo "An unmanaged listener would create a duplicate RabbitMQ consumer." >&2
  exit 1
fi
if ss -H -ltn "sport = :4131" | grep -q .; then
  echo "Dashboard port 4131 remains occupied after the approved service stopped." >&2
  exit 1
fi

next_link="$DEPLOY_ROOT/.current.next.$$"
ln -s "$release_dir" "$next_link"
mv -Tf "$next_link" "$CURRENT_LINK"
switched=1

systemctl --user restart "$DASHBOARD_SERVICE"
if [[ "$listener_was_desired" == "1" ]]; then
  mkdir -p "$PERSISTENT_OUTPUTS/event_listener/control"
  printf 'enabled\n' > "$PERSISTENT_OUTPUTS/event_listener/control/listener.enabled"
  chmod 0600 "$PERSISTENT_OUTPUTS/event_listener/control/listener.enabled"
  systemctl --user enable "$LISTENER_SERVICE" >/dev/null
  systemctl --user restart "$LISTENER_SERVICE"
fi

healthy=0
for _ in {1..30}; do
  if "$CURRENT_LINK/datapipeline-env/bin/python" - "$target_sha" <<'PY'
import json
import sys
import urllib.request
from pathlib import Path

with urllib.request.urlopen("http://127.0.0.1:4131/api/status", timeout=3) as response:
    payload = json.load(response)
status = payload.get("event_listener", {})
if "running" not in status or "manager" not in status or "systemd_running" not in status:
    raise SystemExit("The dashboard is not the expected release API.")
launcher = payload.get("run_launcher", {})
if launcher.get("configured_backend") != "systemd":
    raise SystemExit("The dashboard run manager is not configured for systemd.")
if launcher.get("effective_backend") != "systemd" or not launcher.get("systemd_available"):
    raise SystemExit("The dashboard cannot reach the user-systemd run manager.")
marker = Path("/home/xinzhi/DataPipeline-deploy/current/.datapipeline-release-sha")
if marker.read_text(encoding="utf-8").strip() != sys.argv[1]:
    raise SystemExit("The active release SHA does not match.")
PY
  then
    healthy=1
    break
  fi
  sleep 2
done
if [[ "$healthy" != "1" ]]; then
  echo "DataPipeline dashboard health verification failed." >&2
  exit 1
fi

if [[ "$listener_was_desired" == "1" ]]; then
  "$CURRENT_LINK/datapipeline-env/bin/python" \
    "$CURRENT_LINK/Werkzeuge/check_event_listener_health.py" \
    --api-url "http://127.0.0.1:4131/api/event-listener/status" \
    --dc-root "$CURRENT_LINK/dcp-sdk" \
    --queue-name "$EVENT_QUEUE_NAME" \
    --timeout-seconds 60
fi

trap - EXIT
echo "DataPipeline local artifact deployment completed: $target_sha"
