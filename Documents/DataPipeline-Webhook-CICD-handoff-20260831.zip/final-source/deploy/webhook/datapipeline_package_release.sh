#!/usr/bin/env bash
set -euo pipefail

# Package the exact verified Git tree and Python 3.10 wheelhouse. Production
# consumes this artifact without git access or online dependency installation.

repo_root="${DATAPIPELINE_SOURCE_ROOT:-/workspace}"
if [[ "$repo_root" != /* || ! -d "$repo_root/.git" ]]; then
  echo "DATAPIPELINE_SOURCE_ROOT must be an absolute checked-out Git worktree." >&2
  exit 1
fi
cd "$repo_root"

target_sha="${1:-${RELEASE_SHA:-}}"
if [[ ! "$target_sha" =~ ^[0-9a-f]{40}$ ]]; then
  echo "A full lowercase 40-character release SHA is required." >&2
  exit 2
fi

for command_name in awk basename cp git mkdir python3 rm sha256sum tar; do
  command -v "$command_name" >/dev/null 2>&1 || {
    echo "Missing release packaging prerequisite: $command_name" >&2
    exit 1
  }
done

source_sha="$(git rev-parse HEAD)"
if [[ "$source_sha" != "$target_sha" ]]; then
  echo "Release SHA does not match the checked-out source commit." >&2
  exit 1
fi
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "Release source contains uncommitted tracked changes." >&2
  exit 1
fi
if [[ ! -d "$repo_root/.ci-wheelhouse" ]]; then
  echo "The CI wheelhouse is missing; run isolated release verification first." >&2
  exit 1
fi
if ! compgen -G "$repo_root/.ci-wheelhouse/*.whl" >/dev/null; then
  echo "The release wheelhouse is empty." >&2
  exit 1
fi

python_bin="$repo_root/.ci-venv/bin/python"
if [[ ! -x "$python_bin" ]]; then
  echo "The CI virtual environment is missing." >&2
  exit 1
fi

staging_root="${RUNNER_TEMP:-${TMPDIR:-/tmp}}/datapipeline-release.$$.tmp"
source_archive="${RUNNER_TEMP:-${TMPDIR:-/tmp}}/datapipeline-source.$$.tar"
archive_path="$repo_root/datapipeline-$target_sha.tar.gz"
rm -rf -- "$staging_root"
rm -f -- "$source_archive"
mkdir -p "$staging_root/wheels"
trap 'rm -rf -- "$staging_root"; rm -f -- "$source_archive"' EXIT

git archive --format=tar --output="$source_archive" "$target_sha"
tar -xf "$source_archive" -C "$staging_root"
rm -f -- "$source_archive"
cp -a "$repo_root/.ci-wheelhouse/." "$staging_root/wheels/"
printf '%s\n' "$target_sha" > "$staging_root/.datapipeline-release-sha"

"$python_bin" - "$staging_root/release-manifest.json" "$staging_root/wheels" "$target_sha" <<'PY'
import hashlib
import json
import platform
import sys
from pathlib import Path

manifest_path = Path(sys.argv[1])
wheel_root = Path(sys.argv[2])
target_sha = sys.argv[3]
wheels = []
for wheel in sorted(wheel_root.glob("*.whl")):
    wheels.append(
        {
            "name": wheel.name,
            "sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
        }
    )
if not wheels:
    raise SystemExit("The release wheelhouse is empty.")
manifest = {
    "repository": "yangtianyu/DataPipeline",
    "commit": target_sha,
    "artifact_format": "datapipeline-release-v1",
    "build_python": platform.python_version(),
    "production_python": "3.10",
    "contents": ["tracked_git_tree", "wheels"],
    "wheels": wheels,
}
manifest_path.write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
PY

rm -f -- "$archive_path" "$archive_path.sha256"
tar -czf "$archive_path" -C "$staging_root" .
artifact_hash="$(sha256sum "$archive_path" | awk '{print $1}')"
printf '%s  %s\n' "$artifact_hash" "$(basename "$archive_path")" > "$archive_path.sha256"

echo "$archive_path"
