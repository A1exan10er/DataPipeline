#!/usr/bin/env python3
"""Fixed-scope Gitea push webhook for DataPipeline on host 209."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import stat
import subprocess
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Mapping


BIND_ADDRESS = "172.20.0.1"
PORT = 4014
ENDPOINT = "/gitea/datapipeline"
SECRET_PATH = Path("/home/xinzhi/DataPipeline-deploy/webhook/secret")
JOB_PATH = Path("/usr/local/libexec/datapipeline-webhook-job")
EXPECTED_REPOSITORY = "yangtianyu/datapipeline"
EXPECTED_REF = "refs/heads/master"
MAX_BODY_BYTES = 2 * 1024 * 1024

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


def read_secret() -> bytes:
    if SECRET_PATH.is_symlink() or not SECRET_PATH.is_file():
        raise RuntimeError(f"unsafe webhook secret: {SECRET_PATH}")
    secret_stat = SECRET_PATH.stat()
    if secret_stat.st_uid != os.getuid():
        raise RuntimeError(f"webhook secret is not owned by the service user: {SECRET_PATH}")
    if stat.S_IMODE(secret_stat.st_mode) & 0o077:
        raise RuntimeError(f"webhook secret permissions are too broad: {SECRET_PATH}")
    secret = SECRET_PATH.read_text(encoding="utf-8").strip()
    if not secret:
        raise RuntimeError(f"empty webhook secret: {SECRET_PATH}")
    return secret.encode("utf-8")


def signature_matches(body: bytes, supplied: str, secret: bytes) -> bool:
    if not supplied:
        return False
    supplied = supplied.strip()
    if supplied.startswith("sha256="):
        supplied = supplied.removeprefix("sha256=")
    expected = hmac.new(secret, body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(supplied, expected)


def accepted_sha(headers: Mapping[str, str], payload: object) -> tuple[str, str]:
    if not isinstance(payload, dict):
        return "error", "invalid payload"
    event = str(headers.get("X-Gitea-Event", "")).lower()
    repository_data = payload.get("repository")
    repository = ""
    if isinstance(repository_data, dict):
        repository = str(repository_data.get("full_name", "")).lower()
    ref = str(payload.get("ref", ""))
    commit_sha = str(payload.get("after", "")).lower()
    if event != "push":
        return "ignored", "event"
    if repository != EXPECTED_REPOSITORY or ref != EXPECTED_REF:
        return "ignored", "scope"
    if commit_sha == "0" * 40:
        return "ignored", "branch deletion"
    if len(commit_sha) != 40 or any(ch not in "0123456789abcdef" for ch in commit_sha):
        return "error", "invalid commit SHA"
    return "accepted", commit_sha


class WebhookHandler(BaseHTTPRequestHandler):
    server_version = "datapipeline-webhook/1.0"

    def log_message(self, fmt: str, *args: object) -> None:
        logging.info("%s - %s", self.address_string(), fmt % args)

    def send_json(self, status: HTTPStatus, payload: dict[str, object]) -> None:
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/healthz":
            self.send_json(HTTPStatus.OK, {"status": "ok", "service": "datapipeline-webhook"})
            return
        self.send_json(HTTPStatus.NOT_FOUND, {"error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        if self.path != ENDPOINT:
            self.send_json(HTTPStatus.NOT_FOUND, {"error": "not found"})
            return
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": "invalid content length"})
            return
        if content_length <= 0 or content_length > MAX_BODY_BYTES:
            self.send_json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, {"error": "invalid body size"})
            return

        body = self.rfile.read(content_length)
        try:
            secret = read_secret()
        except (OSError, RuntimeError) as exc:
            logging.error("cannot read webhook secret: %s", exc)
            self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "secret unavailable"})
            return
        supplied_signature = self.headers.get("X-Gitea-Signature") or self.headers.get(
            "X-Hub-Signature-256", ""
        )
        if not signature_matches(body, supplied_signature, secret):
            logging.warning("rejected webhook with invalid signature")
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid signature"})
            return

        try:
            payload = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": "invalid JSON"})
            return

        result, detail = accepted_sha(self.headers, payload)
        logging.info(
            "received event=%s repository=%s ref=%s after=%s delivery=%s result=%s",
            self.headers.get("X-Gitea-Event", ""),
            str(payload.get("repository", {}).get("full_name", ""))
            if isinstance(payload, dict) and isinstance(payload.get("repository"), dict)
            else "",
            str(payload.get("ref", "")) if isinstance(payload, dict) else "",
            str(payload.get("after", "")) if isinstance(payload, dict) else "",
            self.headers.get("X-Gitea-Delivery", ""),
            result,
        )
        if result == "ignored":
            self.send_json(HTTPStatus.ACCEPTED, {"status": "ignored", "reason": detail})
            return
        if result == "error":
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": detail})
            return

        try:
            subprocess.Popen(
                [str(JOB_PATH), detail],
                cwd=str(JOB_PATH.parent),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
                close_fds=True,
            )
        except OSError:
            logging.exception("failed to start fixed DataPipeline job for %s", detail)
            self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "job start failed"})
            return
        self.send_json(HTTPStatus.ACCEPTED, {"status": "accepted", "after": detail})


class ReusableThreadingHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def main() -> None:
    try:
        read_secret()
    except (OSError, RuntimeError) as exc:
        raise SystemExit(str(exc)) from exc
    if JOB_PATH.is_symlink() or not JOB_PATH.is_file():
        raise SystemExit(f"missing or unsafe fixed webhook job: {JOB_PATH}")
    job_stat = JOB_PATH.stat()
    job_mode = stat.S_IMODE(job_stat.st_mode)
    if job_stat.st_uid != 0 or job_mode & 0o022 or not (job_mode & 0o111):
        raise SystemExit(
            f"fixed webhook job must be root-owned, non-writable, and executable: {JOB_PATH}"
        )
    server = ReusableThreadingHTTPServer((BIND_ADDRESS, PORT), WebhookHandler)
    logging.info("DataPipeline webhook listening on %s:%d%s", BIND_ADDRESS, PORT, ENDPOINT)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
