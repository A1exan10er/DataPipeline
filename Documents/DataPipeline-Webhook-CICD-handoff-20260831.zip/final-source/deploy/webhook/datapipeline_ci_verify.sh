#!/usr/bin/env bash
set -euo pipefail

repo_root="${DATAPIPELINE_SOURCE_ROOT:-/workspace}"
if [[ "$repo_root" != /* || ! -d "$repo_root/.git" ]]; then
  echo "DATAPIPELINE_SOURCE_ROOT must be an absolute checked-out Git worktree." >&2
  exit 1
fi
cd "$repo_root"

python3 -m venv .ci-venv
PIP_CONFIG_FILE=/dev/null .ci-venv/bin/python -m pip install \
  --disable-pip-version-check --no-input --upgrade pip
PIP_CONFIG_FILE=/dev/null .ci-venv/bin/python -m pip install \
  --disable-pip-version-check --no-input -r QA_Pipeline/requirements.txt

bash -n QA_Pipeline/scripts/event_listener_control.sh
.ci-venv/bin/python -m compileall -q \
  QA_Pipeline/scripts \
  Werkzeuge \
  data_slow_movement_detection/scripts
.ci-venv/bin/python -m pytest -q

if [[ "${CI_BUILD_RELEASE:-false}" == "true" ]]; then
  rm -rf -- .ci-wheelhouse
  mkdir -m 0700 .ci-wheelhouse
  # The verification image can use a newer Python, but production currently
  # uses CPython 3.10 on Ubuntu 22.04 (glibc 2.35). Include both the baseline
  # manylinux2014 tag and manylinux_2_28, which Pin and its C++ dependencies use.
  PIP_CONFIG_FILE=/dev/null .ci-venv/bin/python -m pip download \
    --disable-pip-version-check \
    --no-cache-dir \
    --only-binary=:all: \
    --platform manylinux_2_28_x86_64 \
    --platform manylinux2014_x86_64 \
    --python-version 3.10 \
    --implementation cp \
    --abi cp310 \
    --dest .ci-wheelhouse \
    -r QA_Pipeline/requirements.txt
  if ! compgen -G ".ci-wheelhouse/*.whl" >/dev/null; then
    echo "The DataPipeline production wheelhouse is empty." >&2
    exit 1
  fi
fi
