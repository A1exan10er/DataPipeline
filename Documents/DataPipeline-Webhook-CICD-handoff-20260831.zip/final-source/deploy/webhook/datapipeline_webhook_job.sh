#!/usr/bin/env bash
set -Eeuo pipefail

# Fixed host-side CI/CD job. Repository code is verified and built only inside
# an isolated container. The host-side deployment entry point is root-owned.

readonly EXPECTED_USER="xinzhi"
readonly DEPLOY_ROOT="${DATAPIPELINE_DEPLOY_ROOT:-/home/xinzhi/DataPipeline-deploy}"
readonly BARE_REPOSITORY="${DATAPIPELINE_BARE_REPOSITORY:-/home/xinzhi/gitea/gitea/git/repositories/yangtianyu/datapipeline.git}"
readonly STATUS_TOKEN_FILE="${DATAPIPELINE_STATUS_TOKEN_FILE:-/home/xinzhi/.config/datapipeline/gitea-status-token}"
readonly GITEA_API_URL="${DATAPIPELINE_GITEA_API_URL:-http://127.0.0.1:3000/api/v1}"
readonly DEPLOY_STATUS_BASE_URL="${DATAPIPELINE_DEPLOY_STATUS_URL:-http://192.168.50.209:4015/deploy-status}"
readonly STATUS_CONTEXT="DataPipeline Webhook CI/CD"
readonly FIXED_DEPLOY_ENTRY="${DATAPIPELINE_DEPLOY_ENTRY:-/usr/local/libexec/datapipeline-webhook-deploy-v1}"
readonly FIXED_CI_VERIFY="/usr/local/libexec/datapipeline-ci-verify"
readonly FIXED_PACKAGE_RELEASE="/usr/local/libexec/datapipeline-package-release"
readonly FIXED_SYSTEMCTL_SHIM="/usr/bin/false"
readonly CI_IMAGE="${DATAPIPELINE_CI_IMAGE:-python:3.10-bookworm}"
readonly CI_CPUS="${DATAPIPELINE_CI_CPUS:-4}"
readonly CI_MEMORY="${DATAPIPELINE_CI_MEMORY:-8g}"
readonly ARTIFACTS_DIR="$DEPLOY_ROOT/artifacts"
readonly COMPLETED_DIR="$DEPLOY_ROOT/webhook-completed"
readonly LOGS_DIR="$DEPLOY_ROOT/webhook/logs"
readonly STATUS_DIR="$DEPLOY_ROOT/webhook/status"
readonly LOCK_PATH="$DEPLOY_ROOT/webhook-deploy.lock"

target_sha="${1:-}"
if [[ ! "$target_sha" =~ ^[0-9a-f]{40}$ ]]; then
  echo "A full lowercase 40-character commit SHA is required." >&2
  exit 2
fi
if [[ "$(id -un)" != "$EXPECTED_USER" ]]; then
  echo "DataPipeline webhook CI/CD must run as $EXPECTED_USER." >&2
  exit 1
fi

umask 077
mkdir -p "$LOGS_DIR" "$STATUS_DIR" "$COMPLETED_DIR" "$ARTIFACTS_DIR"
log_path="$LOGS_DIR/$target_sha.log"
exec > >(tee -a "$log_path") 2>&1

echo "DataPipeline webhook job started: sha=$target_sha"

for command_name in awk basename chmod curl docker flock git install mkdir mktemp mv python3 rm sha256sum stat tee; do
  command -v "$command_name" >/dev/null 2>&1 || {
    echo "Missing webhook job prerequisite: $command_name" >&2
    exit 1
  }
done

require_private_file() {
  local path="$1"
  local label="$2"
  if [[ ! -f "$path" || -L "$path" ]]; then
    echo "Missing protected $label: $path" >&2
    exit 1
  fi
  if [[ "$(stat -c '%U' "$path")" != "$EXPECTED_USER" ]]; then
    echo "$label must be owned by $EXPECTED_USER." >&2
    exit 1
  fi
  local mode
  mode="$(stat -c '%a' "$path")"
  if (( (8#$mode & 8#077) != 0 )); then
    echo "$label must not be accessible by group or other users." >&2
    exit 1
  fi
}

require_root_owned_executable() {
  local path="$1"
  local label="$2"
  if [[ ! -f "$path" || -L "$path" || ! -x "$path" ]]; then
    echo "Missing or unsafe fixed $label: $path" >&2
    exit 1
  fi
  if [[ "$(stat -c '%u' "$path")" != "0" ]]; then
    echo "The fixed $label must be root-owned: $path" >&2
    exit 1
  fi
  local mode
  mode="$(stat -c '%a' "$path")"
  if (( (8#$mode & 8#022) != 0 )); then
    echo "The fixed $label must not be writable by group or other users: $path" >&2
    exit 1
  fi
}

require_private_file "$STATUS_TOKEN_FILE" "Gitea commit-status token"
if [[ ! -d "$BARE_REPOSITORY" ]]; then
  echo "Missing local DataPipeline bare repository: $BARE_REPOSITORY" >&2
  exit 1
fi
require_root_owned_executable "$FIXED_DEPLOY_ENTRY" "deployment entry point"
require_root_owned_executable "$FIXED_CI_VERIFY" "CI verifier"
require_root_owned_executable "$FIXED_PACKAGE_RELEASE" "release packager"
require_root_owned_executable "$FIXED_SYSTEMCTL_SHIM" "CI systemctl shim"

work_root=""
status_curl_config=""
final_status_written=0

write_deploy_state() {
  local state="$1"
  local stage="$2"
  local description="$3"
  local state_file="$STATUS_DIR/$target_sha.json"
  local temporary_file
  temporary_file="$(mktemp "$STATUS_DIR/.${target_sha}.XXXXXX")"
  python3 - "$temporary_file" "$target_sha" "$state" "$stage" "$description" <<'PY'
import datetime
import json
import sys
from pathlib import Path

payload = {
    "sha": sys.argv[2],
    "state": sys.argv[3],
    "stage": sys.argv[4],
    "description": sys.argv[5],
    "updated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
Path(sys.argv[1]).write_text(
    json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8"
)
PY
  chmod 0600 "$temporary_file"
  mv -f -- "$temporary_file" "$state_file"
}

make_status_curl_config() {
  local api_token
  IFS= read -r api_token < "$STATUS_TOKEN_FILE"
  if [[ ! "$api_token" =~ ^[A-Za-z0-9._-]+$ ]]; then
    echo "The Gitea commit-status token is empty or contains unsafe characters." >&2
    return 1
  fi
  status_curl_config="$(mktemp /tmp/datapipeline-status-curl.XXXXXX)"
  chmod 0600 "$status_curl_config"
  printf 'header = "Authorization: token %s"\n' "$api_token" > "$status_curl_config"
  unset api_token
}

set_commit_status() {
  local state="$1"
  local description="$2"
  local payload_file
  payload_file="$(mktemp /tmp/datapipeline-status-payload.XXXXXX)"
  python3 - "$payload_file" "$state" "$description" "$STATUS_CONTEXT" \
    "$DEPLOY_STATUS_BASE_URL/$target_sha" <<'PY'
import json
import sys
from pathlib import Path

payload = {
    "state": sys.argv[2],
    "description": sys.argv[3],
    "context": sys.argv[4],
    "target_url": sys.argv[5],
}
Path(sys.argv[1]).write_text(
    json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8"
)
PY
  if ! curl --config "$status_curl_config" \
    --fail --silent --show-error --connect-timeout 5 --max-time 20 \
    --header 'Content-Type: application/json' \
    --data-binary "@$payload_file" \
    "$GITEA_API_URL/repos/yangtianyu/DataPipeline/statuses/$target_sha" \
    >/dev/null; then
    rm -f -- "$payload_file"
    return 1
  fi
  rm -f -- "$payload_file"
}

finish() {
  local status=$?
  if [[ "$status" != "0" && "$final_status_written" != "1" ]]; then
    write_deploy_state failure failed "CI/CD failed; inspect the sanitized deployment log." || true
    if [[ -n "$status_curl_config" ]]; then
      set_commit_status failure "CI/CD failed; open the deployment status page." || true
    fi
  fi
  if [[ -n "$status_curl_config" ]]; then
    rm -f -- "$status_curl_config"
  fi
  if [[ -n "$work_root" && -d "$work_root" ]]; then
    rm -rf -- "$work_root"
  fi
  exit "$status"
}
trap finish EXIT

write_deploy_state pending waiting "Waiting for the fixed 209 CI/CD job."
make_status_curl_config
set_commit_status pending "Waiting for the fixed 209 CI/CD job."

exec 9>"$LOCK_PATH"
if ! flock -w 5400 9; then
  echo "Timed out waiting for another DataPipeline deployment." >&2
  exit 1
fi

work_root="$(mktemp -d /tmp/datapipeline-webhook.XXXXXX)"
checkout_root="$work_root/datapipeline"
mkdir -p "$work_root/home" "$work_root/ci"
git config --file "$work_root/git-safe-config" --add safe.directory "$BARE_REPOSITORY"
chmod 0600 "$work_root/git-safe-config"
export GIT_CONFIG_GLOBAL="$work_root/git-safe-config"

git --git-dir="$BARE_REPOSITORY" cat-file -e "$target_sha^{commit}"
current_master_sha="$(git --git-dir="$BARE_REPOSITORY" rev-parse refs/heads/master)"
if [[ "$current_master_sha" != "$target_sha" ]]; then
  write_deploy_state skipped superseded "Superseded by a newer master commit."
  set_commit_status skipped "Superseded by a newer master commit."
  final_status_written=1
  echo "Skipping superseded commit: current master is $current_master_sha"
  exit 0
fi

if [[ -f "$COMPLETED_DIR/$target_sha" ]]; then
  write_deploy_state success already-deployed "This commit was already deployed successfully."
  set_commit_status success "This commit was already deployed successfully."
  final_status_written=1
  echo "Commit already completed: $target_sha"
  exit 0
fi

write_deploy_state running verification-build "Running isolated verification and release build."
set_commit_status pending "Running isolated verification and release build."

git clone --no-local --no-hardlinks --no-checkout "$BARE_REPOSITORY" "$checkout_root"
git -C "$checkout_root" checkout --detach "$target_sha"

docker run --rm \
  --user "$(id -u):$(id -g)" \
  --read-only \
  --tmpfs /tmp:rw,exec,nosuid,nodev,size=2g \
  --cap-drop ALL \
  --security-opt no-new-privileges \
  --pids-limit 1024 \
  --cpus "$CI_CPUS" \
  --memory "$CI_MEMORY" \
  --env HOME=/webhook-work/home \
  --env RUNNER_TEMP=/webhook-work/ci \
  --env CI_BUILD_RELEASE=true \
  --env DATAPIPELINE_SOURCE_ROOT=/workspace \
  --env RELEASE_SHA="$target_sha" \
  --env PIP_DEFAULT_TIMEOUT=120 \
  --env PIP_RETRIES=2 \
  --env PIP_INDEX_URL=https://pypi.tuna.tsinghua.edu.cn/simple \
  --volume "$FIXED_CI_VERIFY:/ci-control/datapipeline-ci-verify:ro" \
  --volume "$FIXED_PACKAGE_RELEASE:/ci-control/datapipeline-package-release:ro" \
  --volume "$FIXED_SYSTEMCTL_SHIM:/usr/local/bin/systemctl:ro" \
  --volume "$checkout_root:/workspace:rw" \
  --volume "$work_root:/webhook-work:rw" \
  --workdir /workspace \
  "$CI_IMAGE" \
  bash -lc '/ci-control/datapipeline-ci-verify && /ci-control/datapipeline-package-release "$RELEASE_SHA"'

source_archive="$checkout_root/datapipeline-$target_sha.tar.gz"
source_checksum="$source_archive.sha256"
if [[ ! -f "$source_archive" || ! -f "$source_checksum" ]]; then
  echo "The isolated build did not produce the expected release artifact." >&2
  exit 1
fi
(
  cd "$checkout_root"
  sha256sum -c "$(basename "$source_checksum")"
)

artifact_path="$ARTIFACTS_DIR/datapipeline-$target_sha.tar.gz"
install -m 0600 "$source_archive" "$artifact_path"
install -m 0600 "$source_checksum" "$artifact_path.sha256"

write_deploy_state deploying deploy "Verified artifact built; deploying on 209."
set_commit_status pending "Verified artifact built; deploying on 209."
"$FIXED_DEPLOY_ENTRY" --sha "$target_sha" --artifact "$artifact_path"

printf '%s\n' "$target_sha" > "$COMPLETED_DIR/$target_sha"
chmod 0600 "$COMPLETED_DIR/$target_sha"
write_deploy_state success completed "Verification and deployment succeeded on 209."
set_commit_status success "Verification and deployment succeeded on 209."
final_status_written=1
echo "DataPipeline webhook CI/CD completed: $target_sha"
