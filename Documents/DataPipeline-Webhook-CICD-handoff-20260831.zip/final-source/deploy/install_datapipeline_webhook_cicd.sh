#!/usr/bin/env bash
set -euo pipefail

# One-time maintainer installation of root-owned webhook control files and
# xinzhi user units. It does not create secrets or trigger a deployment.

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

if [[ "$(id -u)" != "0" ]]; then
  echo "Run this installer as root after reviewing the fixed hashes." >&2
  exit 1
fi
if ! id xinzhi >/dev/null 2>&1; then
  echo "The xinzhi account does not exist." >&2
  exit 1
fi

for command_name in id install runuser sha256sum systemctl; do
  command -v "$command_name" >/dev/null 2>&1 || {
    echo "Missing installer prerequisite: $command_name" >&2
    exit 1
  }
done

sha256sum -c deploy/webhook/datapipeline-webhook-deploy-v1.sha256

install -d -o root -g root -m 0755 /usr/local/libexec
install -o root -g root -m 0755 \
  deploy/webhook/datapipeline_webhook_server.py \
  /usr/local/libexec/datapipeline-webhook-server
install -o root -g root -m 0755 \
  deploy/webhook/datapipeline_deploy_status_server.py \
  /usr/local/libexec/datapipeline-deploy-status-server
install -o root -g root -m 0755 \
  deploy/webhook/datapipeline_webhook_job.sh \
  /usr/local/libexec/datapipeline-webhook-job
install -o root -g root -m 0755 \
  deploy/webhook/datapipeline_ci_verify.sh \
  /usr/local/libexec/datapipeline-ci-verify
install -o root -g root -m 0755 \
  deploy/webhook/datapipeline_package_release.sh \
  /usr/local/libexec/datapipeline-package-release
install -o root -g root -m 0755 \
  deploy/webhook/datapipeline_webhook_safety_test.sh \
  /usr/local/libexec/datapipeline-webhook-safety-test
install -o root -g root -m 0755 \
  deploy/webhook/datapipeline-webhook-deploy-v1.sh \
  /usr/local/libexec/datapipeline-webhook-deploy-v1
install -o root -g root -m 0755 \
  deploy/webhook/datapipeline_artifact.py \
  /usr/local/libexec/datapipeline-artifact-verifier

install -d -o xinzhi -g xinzhi -m 0700 /home/xinzhi/.config/systemd/user
install -o xinzhi -g xinzhi -m 0644 \
  deploy/datapipeline-dashboard.service \
  /home/xinzhi/.config/systemd/user/datapipeline-dashboard.service
install -o xinzhi -g xinzhi -m 0644 \
  deploy/datapipeline-event-listener.service \
  /home/xinzhi/.config/systemd/user/datapipeline-event-listener.service
install -o xinzhi -g xinzhi -m 0644 \
  deploy/datapipeline-webhook.service \
  /home/xinzhi/.config/systemd/user/datapipeline-webhook.service
install -o xinzhi -g xinzhi -m 0644 \
  deploy/datapipeline-deploy-status.service \
  /home/xinzhi/.config/systemd/user/datapipeline-deploy-status.service

xinzhi_uid="$(id -u xinzhi)"
runtime_dir="/run/user/$xinzhi_uid"
if [[ ! -S "$runtime_dir/bus" ]]; then
  echo "xinzhi user systemd bus is unavailable; enable linger before installation." >&2
  exit 1
fi
runuser -u xinzhi -- env \
  XDG_RUNTIME_DIR="$runtime_dir" \
  DBUS_SESSION_BUS_ADDRESS="unix:path=$runtime_dir/bus" \
  systemctl --user daemon-reload
runuser -u xinzhi -- env \
  XDG_RUNTIME_DIR="$runtime_dir" \
  DBUS_SESSION_BUS_ADDRESS="unix:path=$runtime_dir/bus" \
  systemctl --user enable datapipeline-dashboard.service
runuser -u xinzhi -- env \
  XDG_RUNTIME_DIR="$runtime_dir" \
  DBUS_SESSION_BUS_ADDRESS="unix:path=$runtime_dir/bus" \
  systemctl --user enable \
    datapipeline-webhook.service \
    datapipeline-deploy-status.service
runuser -u xinzhi -- env \
  XDG_RUNTIME_DIR="$runtime_dir" \
  DBUS_SESSION_BUS_ADDRESS="unix:path=$runtime_dir/bus" \
  systemctl --user restart \
    datapipeline-webhook.service \
    datapipeline-deploy-status.service

echo "DataPipeline fixed webhook CI/CD and status services are installed; the listener and application release were not changed."
