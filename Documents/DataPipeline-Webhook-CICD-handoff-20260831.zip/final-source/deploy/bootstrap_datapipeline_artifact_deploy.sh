#!/usr/bin/env bash
set -euo pipefail

# One-time xinzhi-owned setup for the fixed webhook CI/CD boundary. This
# script does not create credentials, modify Gitea, install units, or deploy.

readonly EXPECTED_USER="xinzhi"
readonly DEPLOY_ROOT="/home/xinzhi/DataPipeline-deploy"
readonly PERSISTENT_ROOT="/home/xinzhi/DataPipeline"
readonly PERSISTENT_OUTPUTS="$PERSISTENT_ROOT/outputs"
readonly DCS_CONFIG_FILE="$PERSISTENT_ROOT/dcp-sdk/dcs_config.json"
readonly TASK_DB_ENV_FILE="/home/xinzhi/.qa_task_db_env"
readonly CONFIG_ROOT="/home/xinzhi/.config/datapipeline"
readonly WEBHOOK_ROOT="$DEPLOY_ROOT/webhook"
readonly BARE_REPOSITORY="${DATAPIPELINE_BARE_REPOSITORY:-/home/xinzhi/gitea/gitea/git/repositories/yangtianyu/datapipeline.git}"

if [[ "$(id -un)" != "$EXPECTED_USER" ]]; then
  echo "Run this setup as $EXPECTED_USER." >&2
  exit 1
fi

for command_name in chmod docker git grep id install ss stat; do
  command -v "$command_name" >/dev/null 2>&1 || {
    echo "Missing bootstrap prerequisite: $command_name" >&2
    exit 1
  }
done

for port in 4014 4015; do
  if ss -H -ltn "sport = :$port" | grep -q .; then
    echo "Required DataPipeline CI/CD port is already occupied: $port" >&2
    exit 1
  fi
done

if [[ ! -d "$PERSISTENT_OUTPUTS" || -L "$PERSISTENT_OUTPUTS" ]]; then
  echo "Missing or unsafe persistent outputs directory: $PERSISTENT_OUTPUTS" >&2
  exit 1
fi

install -d -m 0700 \
  "$CONFIG_ROOT" \
  "$DEPLOY_ROOT" \
  "$DEPLOY_ROOT/releases" \
  "$DEPLOY_ROOT/artifacts" \
  "$DEPLOY_ROOT/webhook-completed" \
  "$WEBHOOK_ROOT" \
  "$WEBHOOK_ROOT/logs" \
  "$WEBHOOK_ROOT/status"

protected_files=(
  "$DCS_CONFIG_FILE"
  "$TASK_DB_ENV_FILE"
  "$CONFIG_ROOT/gitea-status-token"
  "$WEBHOOK_ROOT/secret"
)
for path in "${protected_files[@]}"; do
  if [[ ! -f "$path" || -L "$path" ]]; then
    echo "Create the protected file before completing bootstrap: $path" >&2
    exit 1
  fi
done

chmod 0600 "${protected_files[@]}"
chmod 0700 "$PERSISTENT_OUTPUTS"
for path in "${protected_files[@]}"; do
  if [[ "$(stat -c '%U' "$path")" != "$EXPECTED_USER" ]]; then
    echo "Protected file is not owned by $EXPECTED_USER: $path" >&2
    exit 1
  fi
done
for path in \
  "$CONFIG_ROOT" \
  "$DEPLOY_ROOT" \
  "$DEPLOY_ROOT/releases" \
  "$DEPLOY_ROOT/artifacts" \
  "$DEPLOY_ROOT/webhook-completed" \
  "$WEBHOOK_ROOT" \
  "$WEBHOOK_ROOT/logs" \
  "$WEBHOOK_ROOT/status" \
  "$PERSISTENT_OUTPUTS"; do
  chmod 0700 "$path"
  if [[ "$(stat -c '%U' "$path")" != "$EXPECTED_USER" ]]; then
    echo "Bootstrap path is not owned by $EXPECTED_USER: $path" >&2
    exit 1
  fi
done

if [[ ! -d "$BARE_REPOSITORY" ]]; then
  echo "Missing local Gitea bare repository: $BARE_REPOSITORY" >&2
  exit 1
fi
git -c safe.directory="$BARE_REPOSITORY" --git-dir="$BARE_REPOSITORY" rev-parse --is-bare-repository >/dev/null
git -c safe.directory="$BARE_REPOSITORY" --git-dir="$BARE_REPOSITORY" rev-parse refs/heads/master >/dev/null
docker info >/dev/null

echo "DataPipeline fixed webhook CI/CD directories, credentials, repository, ports, and Docker access are ready."
