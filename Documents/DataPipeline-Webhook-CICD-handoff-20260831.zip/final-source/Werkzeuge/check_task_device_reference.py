#!/usr/bin/env python3
"""Read-only deployment preflight for the production task/device catalog."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="校验任务与机器人类型参考目录。")
    parser.add_argument("--qa-root", required=True, type=Path)
    return parser.parse_args()


def catalog_summary(qa_root: Path) -> dict[str, object]:
    sys.path.insert(0, str(qa_root))
    from scripts.pipeline.task_device_reference import _task_reference_snapshot

    snapshot = _task_reference_snapshot()
    if not snapshot.available:
        raise RuntimeError(snapshot.error or "任务与机器人类型参考目录不可用")
    if not snapshot.mapping:
        raise RuntimeError("任务与机器人类型参考目录为空")
    multi_category_tasks = sum(
        1 for row in snapshot.mapping.values() if len(row.get("categories", [])) > 1
    )
    return {
        "ok": True,
        "source": snapshot.source,
        "task_count": len(snapshot.mapping),
        "multi_category_task_count": multi_category_tasks,
    }


def main() -> int:
    args = parse_args()
    try:
        summary = catalog_summary(args.qa_root)
    except Exception as exc:
        print(f"任务与机器人类型参考目录预检失败：{exc}", file=sys.stderr)
        return 1
    print(json.dumps(summary, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
